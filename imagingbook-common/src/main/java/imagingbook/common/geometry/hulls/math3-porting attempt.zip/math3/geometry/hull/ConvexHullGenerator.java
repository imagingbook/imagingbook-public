/*******************************************************************************
 * This software is provided as a supplement to the authors' textbooks on digital
 * image processing published by Springer-Verlag in various languages and editions.
 * Permission to use and distribute this software is granted under the BSD 2-Clause
 * "Simplified" License (see http://opensource.org/licenses/BSD-2-Clause).
 * Copyright (c) 2006-2025 Wilhelm Burger, Mark J. Burge. All rights reserved.
 * Visit https://imagingbook.com for additional details.
 ******************************************************************************/
package imagingbook.common.geometry.hulls.math3.geometry.hull;

// package org.apache.commons.math3.geometry.hull;

import java.util.Collection;


import org.apache.commons.math4.legacy.exception.ConvergenceException;
import org.apache.commons.math4.legacy.exception.NullArgumentException;
import org.apache.commons.math3.geometry.Point;
import org.apache.commons.math3.geometry.Space;
// import org.apache.commons.math3.exception.ConvergenceException;
// import org.apache.commons.math3.exception.NullArgumentException;
// import org.apache.commons.math3.geometry.Point;
// import org.apache.commons.math3.geometry.Space;

/**
 * Interface for convex hull generators.
 *
 * @param <S> Type of the {@link Space}
 * @param <P> Type of the {@link Point}
 *
 * @see <a href="http://en.wikipedia.org/wiki/Convex_hull">Convex Hull (Wikipedia)</a>
 * @see <a href="http://mathworld.wolfram.com/ConvexHull.html">Convex Hull (MathWorld)</a>
 *
 * @since 3.3
 */
public interface ConvexHullGenerator<S extends Space, P extends Point<S>> {

    /**
     * Builds the convex hull from the set of input points.
     *
     * @param points the set of input points
     * @return the convex hull
     * @throws NullArgumentException if the input collection is {@code null}
     * @throws ConvergenceException if generator fails to generate a convex hull for
     * the given set of input points
     */
    ConvexHull<S, P> generate(Collection<P> points) throws NullArgumentException, ConvergenceException;
}
