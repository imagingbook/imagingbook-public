/*******************************************************************************
 * This software is provided as a supplement to the authors' textbooks on digital
 * image processing published by Springer-Verlag in various languages and editions.
 * Permission to use and distribute this software is granted under the BSD 2-Clause
 * "Simplified" License (see http://opensource.org/licenses/BSD-2-Clause).
 * Copyright (c) 2006-2025 Wilhelm Burger, Mark J. Burge. All rights reserved.
 * Visit https://imagingbook.com for additional details.
 ******************************************************************************/
package imagingbook.common.geometry.hulls.math3.geometry.hull;

// package org.apache.commons.math3.geometry.hull;

import java.io.Serializable;

import org.apache.commons.math3.exception.InsufficientDataException;
import org.apache.commons.math3.geometry.Point;
import org.apache.commons.math3.geometry.Space;
import org.apache.commons.math3.geometry.partitioning.Region;

/**
 * This class represents a convex hull.
 *
 * @param <S> Space type.
 * @param <P> Point type.
 * @since 3.3
 */
public interface ConvexHull<S extends Space, P extends Point<S>> extends Serializable {

    /**
     * Get the vertices of the convex hull.
     * @return vertices of the convex hull
     */
    P[] getVertices();

    /**
     * Returns a new region that is enclosed by the convex hull.
     * @return the region enclosed by the convex hull
     * @throws InsufficientDataException if the number of vertices is not enough to
     * build a region in the respective space
     */
    Region<S> createRegion() throws InsufficientDataException;
}

